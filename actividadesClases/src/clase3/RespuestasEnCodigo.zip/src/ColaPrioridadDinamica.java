public class ColaPrioridadDinamica<T> implements ColaPrioridadTDA<T> {
    private NodoPrioridad<T> primero;

    @Override
    public void inicializarCola() {
        primero = null;
    }

    @Override
    public void acolarPrioridad(T x, int prioridad) {
        NodoPrioridad<T> nuevo = new NodoPrioridad<>(x, prioridad);
        if (primero == null || prioridad > primero.prioridad) {
            nuevo.siguiente = primero;
            primero = nuevo;
        } else {
            NodoPrioridad<T> actual = primero;
            while (actual.siguiente != null && actual.siguiente.prioridad >= prioridad) {
                actual = actual.siguiente;
            }
            nuevo.siguiente = actual.siguiente;
            actual.siguiente = nuevo;
        }
    }

    @Override
    public void desacolar() {
        if (primero != null) {
            primero = primero.siguiente;
        }
    }

    @Override
    public T primero() {
        return primero.dato;
    }

    @Override
    public int prioridad() {
        return primero.prioridad;
    }

    @Override
    public boolean colaVacia() {
        return primero == null;
    }
}
