
public class EjerciciosCodeados {
    public static void main(String[] args) {

        ColaTDA<String> filaBanco = new ColaDinamica();
        filaBanco.inicializarCola();

        ColaTDA<String> ColaArchivo = new ColaDinamica<>();
        ColaArchivo.inicializarCola();

        ColaPrioridadTDA<String> guardia = new ColaPrioridadDinamica<>();
        guardia.inicializarCola();

        ColaPrioridadTDA<String> filaExamen = new ColaPrioridadDinamica<>();
        filaExamen.inicializarCola();

        ColaPrioridadTDA<String> scheduler = new ColaPrioridadDinamica<>();
        scheduler.inicializarCola();

        ColaPrioridadTDA<String> embarque = new ColaPrioridadDinamica<>();
        embarque.inicializarCola();

        ColaPrioridadTDA<String> soporteIT = new ColaPrioridadDinamica<>();
        soporteIT.inicializarCola();

        filaBanco.acolar("Cliente 1");
        filaBanco.acolar("Cliente 2");
        filaBanco.acolar("Cliente 3");
        filaBanco.acolar("Cliente 4");
        filaBanco.acolar("Cliente 5");

        while (!filaBanco.colaVacia()) {
            String turnoActual = filaBanco.primero();
            System.out.println(turnoActual);
            filaBanco.desacolar();
        }
        System.out.println("");
        System.out.println("Ejercicio 2");
        System.out.println("");
        ColaArchivo.acolar("Archivo2");
        ColaArchivo.acolar("Archivo1");
        ColaArchivo.acolar("Archivo5");
        ColaArchivo.acolar("Archivo3");
        ColaArchivo.acolar("Archivo4");

        while (!ColaArchivo.colaVacia()) {
            String archivo = ColaArchivo.primero();
            System.out.println(archivo);
            ColaArchivo.desacolar();
        }

        System.out.println("");
        System.out.println("Ejercicio 3");
        System.out.println("");

        guardia.acolarPrioridad("Pibe con raspón", 1);
        guardia.acolarPrioridad("Jubilado con bobazo", 100);

        // 3 casos a elección
        guardia.acolarPrioridad("Fractura expuesta", 80);
        guardia.acolarPrioridad("Gripe fuerte", 20);
        guardia.acolarPrioridad("Renovar receta", 5);

        // Desencolamos e imprimimos
        while (!guardia.colaVacia()) {
            System.out.println(guardia.primero() + " (Prioridad: " + guardia.prioridad() + ")");
            guardia.desacolar();
        }

        System.out.println("");
        System.out.println("Ejercicio 4");
        System.out.println("");

        filaExamen.acolarPrioridad("Alumno Regular", 5);
        filaExamen.acolarPrioridad("Alumno Promocionado", 10);

        while (!filaExamen.colaVacia()) {
            System.out.println(filaExamen.primero() + " (Prioridad: " + filaExamen.prioridad() + ")");
            filaExamen.desacolar();
        }
        System.out.println("");
        System.out.println("Ejercicio 5");
        System.out.println("");

        scheduler.acolarPrioridad("Spotify", 10);
        scheduler.acolarPrioridad("Google Chrome", 10);
        scheduler.acolarPrioridad("Gestor de Memoria", 50);
        scheduler.acolarPrioridad("Antivirus del SO", 50);

        while (!scheduler.colaVacia()) {
            System.out.println("Ejecutando proceso: " + scheduler.primero() + " (Prioridad: " + scheduler.prioridad() + ")");
            scheduler.desacolar();
        }

        System.out.println("");
        System.out.println("Ejercicio 6");
        System.out.println("");

        embarque.acolarPrioridad("Mortal 1 (Llegó primero)", 1);
        embarque.acolarPrioridad("Mortal 2 (Llegó segundo)", 1);
        embarque.acolarPrioridad("Pasajero Business", 2);

        while (!embarque.colaVacia()) {
            System.out.println("Sube: " + embarque.primero() + " (Prioridad: " + embarque.prioridad() + ")");
            embarque.desacolar();
        }

        System.out.println("");
        System.out.println("Ejercicio 7");
        System.out.println("");

        soporteIT.acolarPrioridad("Ticket: No me gusta el fondo de pantalla", 0);
        soporteIT.acolarPrioridad("Ticket: SE ROMPIÓ EL SERVIDOR PRINCIPAL", 999);

        while (!soporteIT.colaVacia()) {
            System.out.println("Resolviendo: " + soporteIT.primero() + " (Prioridad: " + soporteIT.prioridad() + ")");
            soporteIT.desacolar();
        }


    }
}